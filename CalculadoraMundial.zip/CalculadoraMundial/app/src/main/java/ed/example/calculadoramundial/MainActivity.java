package ed.example.calculadoramundial;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {


    private EditText valor01;
    private EditText valor02;
    private RadioButton oper01;
    private RadioButton oper02;
    private RadioButton oper03;
    private RadioButton oper04;
    private Button Boton01;
    private TextView Textsal01;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        valor01=findViewById(R.id.editText1);
        valor02=findViewById(R.id.editText2);
        oper01=findViewById(R.id.radioButton);
        oper02=findViewById(R.id.radioButton2);
        oper03=findViewById(R.id.radioButton3);
        oper04=findViewById(R.id.radioButton4);
        Boton01=findViewById(R.id.button2);
        Textsal01=findViewById(R.id.textView2);
    }
    public void calcular(View v) {
        int resultado = 0;
        if( valor01.getText().length()==0){Textsal01.setText("error");}
        else {

            if (valor02.getText().length() == 0) {
                Textsal01.setText("error");
            }
            else{
                Textsal01.setText("resultado"+valor01.getText().toString()+"AA"+valor02.getText().toString());
                   if (oper01.isChecked()) {
                        resultado = Integer.parseInt(valor01.getText().toString()) + Integer.parseInt(valor02.getText().toString());
                        Textsal01.setText(String.valueOf(resultado));
                    }
                    if (oper02.isChecked()) {
                        resultado = Integer.parseInt(valor01.getText().toString()) - Integer.parseInt(valor02.getText().toString());
                       Textsal01.setText(String.valueOf(resultado));
                   }
                    if (oper03.isChecked()) {
                        resultado = Integer.parseInt(valor01.getText().toString()) * Integer.parseInt(valor02.getText().toString());
                       Textsal01.setText(String.valueOf(resultado));
                    }
                    if (oper04.isChecked()) {
                 if(Integer.parseInt(valor02.getText().toString())==0){ Textsal01.setText("error");}
                  else{
                        resultado = Integer.parseInt(valor01.getText().toString()) / Integer.parseInt(valor02.getText().toString());

                        Textsal01.setText(String.valueOf(resultado));}
                    }


            }


        }




    }


    }